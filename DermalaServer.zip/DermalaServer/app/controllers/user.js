'use strict'

var mongoose = require('mongoose')
var User = mongoose.model('User')
var xss = require('xss')
var users = {}

console.log('signup')
users.signup = function * (next) {
    console.log('s')
    //var phoneNumber = this.request.body.phoneNumber
    var phoneNumber = this.query.phoneNumber
    console.log('1')
    var user = yield User.findOne({
        phoneNumber:phoneNumber
    }).exec()

    if(!user) {
        user = new User({
            phoneNumber:xss(phoneNumber)
        })
    }
    else {
        user.verifyCode = '1212'
    }
    try {
        user = yield user.save()
    }
    catch(e) {
        this.body = {
            success : false
        }
        return
    }

    this.body = {
        success: true
    }
},
    users.verify = function * (next) {
    this.body = {
        success: true
    }
},
    users.update = function * (next) {
    this.body = {
        success: true
    }
}
module.exports = users