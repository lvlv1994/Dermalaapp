'use strict'
var Router = require('koa-router')
var users = require('../app/controllers/user')
var App = require('../app/controllers/app')

module.exports = function() {
    var router = new Router ({
        prefix:'/api/1'
    })
//user

    router.get('/u/signup',users.signup)
    router.post('/u/verify',users.verify)
    router.post('/u/update',users.update)
    //app
    router.post('/signature',App.signature)

    return router
}